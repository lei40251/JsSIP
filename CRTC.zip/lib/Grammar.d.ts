export type Grammar = any;

export function parse(input: string, startRule?: string): Grammar;

export function toSource(): any;
