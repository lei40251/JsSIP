"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function"); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, writable: true, configurable: true } }); Object.defineProperty(subClass, "prototype", { writable: false }); if (superClass) _setPrototypeOf(subClass, superClass); }

function _setPrototypeOf(o, p) { _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) { o.__proto__ = p; return o; }; return _setPrototypeOf(o, p); }

function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _getPrototypeOf(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _getPrototypeOf(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _possibleConstructorReturn(this, result); }; }

function _possibleConstructorReturn(self, call) { if (call && (_typeof(call) === "object" || typeof call === "function")) { return call; } else if (call !== void 0) { throw new TypeError("Derived constructors may only return object or undefined"); } return _assertThisInitialized(self); }

function _assertThisInitialized(self) { if (self === void 0) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return self; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {})); return true; } catch (e) { return false; } }

function _getPrototypeOf(o) { _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) { return o.__proto__ || Object.getPrototypeOf(o); }; return _getPrototypeOf(o); }

var EventEmitter = require('events').EventEmitter;

module.exports = /*#__PURE__*/function (_EventEmitter) {
  _inherits(getStats, _EventEmitter);

  var _super = _createSuper(getStats);

  function getStats(pc) {
    var _this;

    var delay = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 1;

    _classCallCheck(this, getStats);

    _this = _super.call(this);
    _this._pc = pc;
    _this._delay = delay;
    _this._statsTimer;
    _this._stats = {
      audio: {
        bytesSent: null,
        packetsSent: null,
        packetsSentLost: null,
        bytesReceived: null,
        packetsReceived: null,
        packetsReceivedLost: null,
        uplinkRTT: null,
        uplinkLoss: null,
        uplinkSpeed: null,
        downlinkRTT: null,
        downlinkLoss: null,
        downlinkSpeed: null
      },
      video: {
        packetsSent: null,
        packetsSentLost: null,
        packetsReceived: null,
        packetsReceivedLost: null,
        bytesSent: null,
        bytesReceived: null,
        uplinkRTT: null,
        uplinkLoss: null,
        uplinkSpeed: null,
        downlinkRTT: null,
        downlinkLoss: null,
        downlinkSpeed: null,
        framesEncoded: null,
        framesDecoded: null,
        framesSent: null,
        framesReceived: null,
        upFrameHeight: null,
        upFrameWidth: null,
        downFrameHeight: null,
        downFrameWidth: null
      }
    };
    _this._cStats = {
      audio: {
        bytesSent: null,
        packetsSent: null,
        packetsSentLost: null,
        bytesReceived: null,
        packetsReceived: null,
        packetsReceivedLost: null
      },
      video: {
        packetsSent: null,
        packetsSentLost: null,
        packetsReceived: null,
        packetsReceivedLost: null,
        bytesSent: null,
        bytesReceived: null
      }
    };

    _this.start();

    return _this;
  }

  _createClass(getStats, [{
    key: "start",
    value: function start() {
      var _this2 = this;

      this._statsTimer = setInterval(function () {
        _this2._pc.getStats().then(function (stats) {
          _this2.parseReport(stats);
        });
      }, this._delay * 1000);
    }
  }, {
    key: "stop",
    value: function stop() {
      clearInterval(this._statsTimer);
    } // 参考 https://blog.csdn.net/weixin_41821317/article/details/117261117
    // https://www.twilio.com/blog/2016/03/chrome-vs-firefox-webrtc-stats-api-with-twilio-video.html

  }, {
    key: "parseReport",
    value: function parseReport(stats) {
      var _this3 = this;

      stats.forEach(function (report) {
        switch (report.type) {
          case 'remote-inbound-rtp':
            if (report.kind === 'video') {
              _this3._stats.video.uplinkRTT = report['roundTripTime'];
              _this3._cStats.video.packetsSentLost = report['packetsLost'] - (_this3._stats.video.packetsSentLost ? _this3._stats.video.packetsSentLost : 0);
              _this3._stats.video.packetsSentLost = report['packetsLost'];
            } else if (report.kind === 'audio') {
              _this3._stats.audio.uplinkRTT = report['roundTripTime'];
              _this3._cStats.audio.packetsSentLost = report['packetsLost'] - (_this3._stats.audio.packetsSentLost ? _this3._stats.audio.packetsSentLost : 0);
              _this3._stats.audio.packetsSentLost = report['packetsLost'];
            }

            break;

          case 'remote-outbound-rtp':
            if (report.kind === 'video') {
              _this3._stats.video.downlinkRTT = report['roundTripTime'];
            } else if (report.kind === 'audio') {
              _this3._stats.audio.downlinkRTT = report['roundTripTime'];
            }

            break;

          case 'outbound-rtp':
            if (report.kind === 'video') {
              _this3._cStats.video.packetsSent = report['packetsSent'] - (_this3._stats.video.packetsSent ? _this3._stats.video.packetsSent : 0);
              _this3._cStats.video.bytesSent = report['bytesSent'] - (_this3._stats.video.bytesSent ? _this3._stats.video.bytesSent : 0);
              _this3._stats.video.packetsSent = report['packetsSent'];
              _this3._stats.video.bytesSent = report['bytesSent'];
              _this3._stats.video.upFrameHeight = report['frameHeight'];
              _this3._stats.video.upFrameWidth = report['frameWidth'];
              _this3._stats.video.framesEncoded = report['framesEncoded'];
              _this3._stats.video.framesSent = report['framesSent'];
            } else if (report.kind === 'audio') {
              _this3._cStats.audio.packetsSent = report['packetsSent'] - (_this3._stats.audio.packetsSent ? _this3._stats.audio.packetsSent : 0);
              _this3._cStats.audio.bytesSent = report['bytesSent'] - (_this3._stats.audio.bytesSent ? _this3._stats.audio.bytesSent : 0);
              _this3._stats.audio.packetsSent = report['packetsSent'];
              _this3._stats.audio.bytesSent = report['bytesSent'];
            }

            break;

          case 'inbound-rtp':
            if (report.kind === 'video') {
              _this3._cStats.video.packetsReceived = report['packetsReceived'] - (_this3._stats.video.packetsReceived ? _this3._stats.video.packetsReceived : 0);
              _this3._cStats.video.bytesReceived = report['bytesReceived'] - (_this3._stats.video.bytesReceived ? _this3._stats.video.bytesReceived : 0);
              _this3._cStats.video.packetsReceivedLost = report['packetsLost'] - (_this3._stats.video.packetsReceivedLost ? _this3._stats.video.packetsReceivedLost : 0);
              _this3._stats.video.packetsReceived = report['packetsReceived'];
              _this3._stats.video.bytesReceived = report['bytesReceived'];
              _this3._stats.video.packetsReceivedLost = report['packetsLost'];
              _this3._stats.video.downFrameHeight = report['frameHeight'];
              _this3._stats.video.downFrameWidth = report['frameWidth'];
              _this3._stats.video.framesDecoded = report['framesDecoded'];
              _this3._stats.video.framesReceived = report['framesReceived'];
            } else if (report.kind === 'audio') {
              _this3._cStats.audio.packetsReceived = report['packetsReceived'] - (_this3._stats.audio.packetsReceived ? _this3._stats.audio.packetsReceived : 0);
              _this3._cStats.audio.bytesReceived = report['bytesReceived'] - (_this3._stats.audio.bytesReceived ? _this3._stats.audio.bytesReceived : 0);
              _this3._cStats.audio.packetsReceivedLost = report['packetsLost'] - (_this3._stats.audio.packetsReceivedLost ? _this3._stats.audio.packetsReceivedLost : 0);
              _this3._stats.audio.packetsReceived = report['packetsReceived'];
              _this3._stats.audio.bytesReceived = report['bytesReceived'];
              _this3._stats.audio.packetsReceivedLost = report['packetsLost'];
            }

            break;

          default:
            break;
        }
      }); // 语音上行丢包率

      if (this._cStats.audio.packetsSent === null) {
        this._stats.audio.uplinkLoss = null;
      } else if (this._cStats.audio.packetsSentLost === null) {
        this._stats.audio.uplinkLoss = null;
      } else {
        var audioUplinkLoss = 0;

        if (this._cStats.audio.packetsSent === 0) {
          audioUplinkLoss = 100;
        } else {
          audioUplinkLoss = Math.floor(this._cStats.audio.packetsSentLost * 100 / (this._cStats.audio.packetsSentLost + this._cStats.audio.packetsSent));
        }

        if (audioUplinkLoss >= 0) {
          this._stats.audio.uplinkLoss = audioUplinkLoss;
        }
      } // 语音上行速率


      if (this._cStats.audio.bytesSent === null) {
        this._stats.audio.uplinkSpeed = null;
      } else {
        this._stats.audio.uplinkSpeed = this._cStats.audio.bytesSent / this._delay * 8;
      } // 语音下行丢包率


      if (this._cStats.audio.packetsReceived === null) {
        this._stats.audio.downlinkLoss = null;
      } else if (this._cStats.audio.packetsReceivedLost === null) {
        this._stats.audio.downlinkLoss = null;
      } else {
        var audioDownlinkLoss = 0;

        if (this._cStats.audio.packetsReceived === 0) {
          audioDownlinkLoss = 100;
        } else {
          audioDownlinkLoss = Math.floor(this._cStats.audio.packetsReceivedLost * 100 / (this._cStats.audio.packetsReceivedLost + this._cStats.audio.packetsReceived));
        }

        if (audioDownlinkLoss >= 0) {
          this._stats.audio.downlinkLoss = audioDownlinkLoss;
        }
      } // 语音下行速率


      if (this._cStats.audio.bytesReceived === null) {
        this._stats.audio.downlinkSpeed = null;
      } else {
        this._stats.audio.downlinkSpeed = this._cStats.audio.bytesReceived / this._delay * 8;
      } // 视频上行丢包率


      if (this._cStats.video.packetsSent === null) {
        this._stats.video.uplinkLoss = null;
      } else if (this._cStats.video.packetsSentLost === null) {
        this._stats.video.uplinkLoss = null;
      } else {
        var videoUplinkLoss = 0;

        if (this._cStats.video.packetsSent === 0) {
          videoUplinkLoss = 100;
        } else {
          videoUplinkLoss = Math.floor(this._cStats.video.packetsSentLost * 100 / (this._cStats.video.packetsSentLost + this._cStats.video.packetsSent));
        }

        if (videoUplinkLoss >= 0) {
          this._stats.video.uplinkLoss = videoUplinkLoss;
        }
      } // 视频上行速率


      if (this._cStats.video.bytesSent === null) {
        this._stats.video.uplinkSpeed = null;
      } else {
        this._stats.video.uplinkSpeed = this._cStats.video.bytesSent / this._delay * 8;
      } // 视频下行丢包率


      if (this._cStats.video.packetsReceived === null || this._cStats.video.packetsReceivedLost === null) {
        this._stats.video.downlinkLoss = null;
      } else {
        var videoDownlinkLoss = 0;

        if (this._cStats.video.packetsReceived === 0) {
          videoDownlinkLoss = 100;
        } else {
          videoDownlinkLoss = Math.floor(this._cStats.video.packetsReceivedLost * 100 / (this._cStats.video.packetsReceivedLost + this._cStats.video.packetsReceived));
        }

        if (videoDownlinkLoss >= 0) {
          this._stats.video.downlinkLoss = videoDownlinkLoss;
        }
      } // 视频下行速率


      if (this._cStats.video.bytesReceived === null) {
        this._stats.video.downlinkSpeed = null;
      } else {
        this._stats.video.downlinkSpeed = this._cStats.video.bytesReceived / this._delay * 8;
      }

      function parseStatsReport(report) {
        var rp = {
          transport: {
            uplinkRTT: report.audio.uplinkRTT > report.video.uplinkRTT ? report.audio.uplinkRTT : report.video.uplinkRTT
          },
          audio: {
            bytesSent: report.audio.bytesSent,
            packetsSent: report.audio.packetsSent,
            uplinkLoss: report.audio.uplinkLoss,
            uplinkSpeed: report.audio.uplinkSpeed,
            bytesReceived: report.audio.bytesReceived,
            packetsReceived: report.audio.packetsReceived,
            downlinkLoss: report.audio.downlinkLoss,
            downlinkSpeed: report.audio.downlinkSpeed
          },
          video: {
            bytesSent: report.video.bytesSent,
            packetsSent: report.video.packetsSent,
            framesSent: report.video.framesSent,
            framesEncoded: report.video.framesEncoded,
            upFrameWidth: report.video.upFrameWidth,
            upFrameHeight: report.video.upFrameHeight,
            uplinkLoss: report.video.uplinkLoss,
            uplinkSpeed: report.video.uplinkSpeed,
            bytesReceived: report.video.bytesReceived,
            packetsReceived: report.video.packetsReceived,
            framesReceived: report.video.framesReceived,
            framesDecoded: report.video.framesDecoded,
            downFrameWidth: report.video.downFrameWidth,
            downFrameHeight: report.video.downFrameHeight,
            downlinkLoss: report.video.downlinkLoss,
            downlinkSpeed: report.video.downlinkSpeed
          }
        };
        return {
          uplinkRTT: rp.transport.uplinkRTT,
          upFrameWidth: rp.video.upFrameWidth,
          upFrameHeight: rp.video.upFrameHeight,
          downFrameWidth: rp.video.downFrameWidth,
          downFrameHeight: rp.video.downFrameHeight,
          uplinkSpeed: "".concat(((rp.video.uplinkSpeed + rp.audio.uplinkSpeed) / 1000).toFixed(1), "kbps"),
          downlinkSpeed: "".concat(((rp.video.downlinkSpeed + rp.audio.downlinkSpeed) / 1000).toFixed(1), "kbps"),
          downlinkLoss: "".concat(rp.audio.downlinkLoss > rp.video.downlinkLoss ? rp.audio.downlinkLoss : rp.video.downlinkLoss, "%")
        };
      }

      this.emit('report', parseStatsReport(this._stats));
    }
  }]);

  return getStats;
}(EventEmitter);