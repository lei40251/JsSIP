THANKS
======

Here the list of contributors with code and patches to JsSIP project. Thanks a lot to all.

* [vf1](https://github.com/vf1)
* [Pedro Kiefer](https://github.com/pedrokiefer)
* [Iwan Budi Kusnanto](https://github.com/iwanbk)
* Davide Corda
* [Anthony Minessale](https://github.com/FreeSWITCH)
* [Gavin Llewellyn](https://github.com/gavllew)
* [Julian Scheid](https://github.com/jscheid)
* [James Mortensen](https://github.com/jamesmortensen)
* [Steve Davies](https://github.com/davies147)
* [Douglas Amorim Ferreira](https://github.com/douglaseel)


JsSIP Debian and Ubuntu packaging

* [Daniel Pocock](https://github.com/dpocock)


JsSIP Bower packaging

* [Linda Nichols](https://github.com/lynnaloo)
