
// 信令地址
const signalingUrl = 'wss://5g.vsbc.com:9002/wss';
// const signalingUrl = 'wss://pro.vsbc.com:60041/wss';
// sip domain
const sipDomain = '5g.vsbc.com';
// const sipDomain = 'pro.vsbc.com';